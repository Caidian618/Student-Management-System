
public class StudentManager {
	public static void main(String[] args) {
		 new MyFrame("ѧ��ѡ��ϵͳ");
	}
}
