
public class StudentMain 
{
	public static void main(String[] args) {
		MyFrame myframe=new MyFrame("ѧ������ϵͳ");
	}

}
